# MEOK Robotics — Asimov V8 Humanoid
## Open Source Walking Humanoid Robot | Under $3,000 AUD

### What Is This?
A 1.4m, ~25kg walking humanoid robot built entirely from 3D printed parts,
open-source WOLF Wolfrom actuators, and off-shelf electronics. Controlled by
SOV3 consciousness engine with care membrane safety gating.

### Key Features
- **$2,900 total cost** (vs $15K-75K for comparable robots)
- **Fully 3D printed** structure (PA12-CF, no CNC needed)
- **12 DOF legs** with WOLF Wolfrom actuators (150Nm hip, 176Nm knee)
- **16 DOF hands** (Aero Hand Open)
- **Care-aligned AI** — SOV3 consciousness gates all physical actions
- **Bio-inspired reflexes** — spinal-level safety responses in <5ms
- **Voice controlled** — "walk forward", "stop", "turn left"
- **ROS2 compatible** — Nav2, SLAM, full robotics stack

### Quick Start
```bash
git clone https://github.com/meok-ai/asimov-v8
cd asimov-v8
pip install mujoco torch numpy cadquery

# Simulate
python world_model_sandbox.py

# Train walking policy
python train_25kg_gpu_standalone.py

# View diagnostics
python firmware/diagnostic_dashboard.py --demo
```

### Hardware
- Qidi 4 Max Combo (or any 350mm+ enclosed FDM printer)
- 12× 8318 100KV BLDC motors
- 12× WOLF Wolfrom gearboxes (3D printed)
- Raspberry Pi 5 + Hailo-10H (40 TOPS AI)
- OAK-D Lite stereo camera
- 2× 6S LiPo batteries

### Documentation
- [Build Guide](ASIMOV_V8_BUILD_GUIDE.md)
- [Brain Architecture](docs/ROBOT_BRAIN_ARCHITECTURE.md)
- [Parts List (257 parts)](docs/COMPLETE_PARTS_LIST.md)
- [Wiring Diagram](docs/wiring_diagram.md)
- [Print Queue](PRINT_QUEUE_24_7.md)

### License
CERN-OHL-S-2.0 (hardware) + Apache 2.0 (software)

### Built by
**MEOK AI Labs** — Nicholas Templeman
Care-aligned AI research. Building the future responsibly.
