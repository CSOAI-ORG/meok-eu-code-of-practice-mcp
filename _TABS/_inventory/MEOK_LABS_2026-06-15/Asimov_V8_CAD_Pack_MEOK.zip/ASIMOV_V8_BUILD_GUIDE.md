# Asimov v8 — Complete Build Guide
## MEOK AI Labs | Manufacturing Topology & Assembly Instructions
### Generated 2026-04-19 | All dimensions verified against MuJoCo physics model

---

## OVERVIEW

| Spec | Value |
|------|-------|
| Robot | Asimov v8 Optimised |
| Scale | 1.17x (original Asimov v1) |
| Height | ~1.4m standing |
| Mass | 12.4kg (simulation verified) |
| DOF | 12 actuated + 2 passive arms + 2 passive toes |
| Actuators | 12x WOLF Wolfrom + BLDC motors |
| Compute | RPi5 + Hailo-10H (40 TOPS) + STM32 (200Hz) |
| Cost | ~$2,900 AUD |
| Printer | Qidi 4 Max Combo (350×350×380mm) |

---

## PART 1: PRINTED PARTS CATALOGUE

### All 15 structural parts + 10 TPU pads + 2 arm tubes = 27 printed pieces

#### PA6-CF Parts (7 parts — highest stress, anneal after printing)

| # | Part | Dims (mm) | Infill | Orientation | Est. Time | Fits? |
|---|------|-----------|--------|-------------|-----------|-------|
| 1 | pelvis_link | 100×158×208 | 40% gyroid | Upright (standing) | 26.5h | YES |
| 2 | left_hip_yaw | 73×75×229 | 35% gyroid | Upright, joint axis vertical | 8.8h | YES |
| 3 | left_knee | 124×102×370 | 40% gyroid | Flat on flexion face | 37.3h | YES (10.5mm Z clearance) |
| 4 | left_ankle_pitch | 51×52×53 | 40% gyroid | Flat | 1.1h | YES |
| 5 | right_hip_yaw | 73×75×229 | 35% gyroid | Upright, joint axis vertical | 8.8h | YES |
| 6 | right_knee | 124×102×370 | 40% gyroid | Flat on flexion face | 37.3h | YES (10.5mm Z clearance) |
| 7 | right_ankle_pitch | 51×52×53 | 40% gyroid | Flat | 1.1h | YES |

**PA6-CF Print Settings:**
```
Nozzle: 300°C (hardened steel 0.4mm ONLY)
Bed: 110°C (smooth PEI)
Chamber: 60°C (max)
Speed: 60mm/s walls, 100mm/s infill, 25mm/s first layer
Retraction: 0.6mm at 35mm/s
Cooling: 0% layers 1-5, 15% after layer 6
Flow: 0.96
Brim: 8mm
Layer height: 0.2mm (0.16mm for bearing bores)
Shrinkage compensation: X/Y scale 100.8% (101.2% if annealing)
DRY: 90°C for 4hr minimum before print, keep dryer running during print
```

**Annealing Protocol (mandatory for PA6-CF):**
1. Oven to 130°C (convection, verify with thermocouple)
2. Place parts on flat ceramic tile with weights on critical surfaces
3. Ramp: room temp → 130°C over 30 min
4. Hold 130°C for 2 hours
5. Cool in closed oven to room temp (4+ hours, DO NOT OPEN)
6. Result: +20-25% tensile, +15% HDT. Parts shrink 0.3-0.5% uniformly

#### PA12-CF Parts (8 parts — standard structural)

| # | Part | Dims (mm) | Infill | Orientation | Est. Time | Fits? |
|---|------|-----------|--------|-------------|-----------|-------|
| 8 | left_hip_pitch | 75×76×82 | 25% gyroid | On side, pivot axis vertical | 2.3h | YES |
| 9 | left_hip_roll | 57×79×171 | 25% gyroid | Upright | 3.8h | YES |
| 10 | left_ankle_roll | 71×97×149 | 30% gyroid | Flat, foot mount on top | 6.2h | YES |
| 11 | left_toe | 44×72×95 | 25% gyroid | Sole-down on smooth PEI | 1.5h | YES |
| 12 | right_hip_pitch | 75×76×82 | 25% gyroid | On side, pivot axis vertical | 2.3h | YES |
| 13 | right_hip_roll | 57×79×171 | 25% gyroid | Upright | 3.8h | YES |
| 14 | right_ankle_roll | 71×97×149 | 30% gyroid | Flat, foot mount on top | 6.2h | YES |
| 15 | right_toe | 44×72×95 | 25% gyroid | Sole-down on smooth PEI | 1.5h | YES |

**PA12-CF Print Settings:**
```
Nozzle: 280°C (hardened steel 0.4mm)
Bed: 100°C (smooth PEI)
Chamber: 55°C
Speed: 80mm/s walls, 120mm/s infill, 30mm/s first layer
Retraction: 0.8mm at 40mm/s
Cooling: 0% layers 1-3, 30% after layer 4
Flow: 0.98
Brim: 5mm
Layer height: 0.2mm
Shrinkage compensation: X/Y scale 100.5%
DRY: 70°C for 2hr before print
```

#### TPU 95A Parts (10 foot pads + 2 arm tubes = 12 parts)

| # | Part | Description | Infill | Notes |
|---|------|-------------|--------|-------|
| 16-19 | Heel pads ×4 | 20mm sphere, 60mm behind ankle | 30% | Print tread-down |
| 20-23 | Fore pads ×4 | 20mm sphere, 90mm forward | 30% | Print tread-down |
| 24-25 | Medial/lateral ×4 | 14mm sphere, ±30mm | 30% | Batch print |
| 26-27 | Arm tubes ×2 | 15mm×300mm capsule | 20% | Passive pendulums |

**TPU 95A Print Settings:**
```
Nozzle: 225°C
Bed: 50°C
Chamber: OFF (open door)
Speed: 25mm/s all moves, 15mm/s first layer
Retraction: 0.3mm at 20mm/s (MINIMAL)
Cooling: 80% after layer 2
Flow: 1.05
No brim needed
Layer height: 0.2mm
Filament path: ensure no gaps where TPU can buckle
```

---

## PART 2: PRINT SCHEDULE (14 days, single printer)

### Day 1-2: PA6-CF — Pelvis + Hip Yaw
```
Day 1 AM: Dry PA6-CF at 90°C for 4hr
Day 1 PM: Start pelvis (26.5hr overnight print)
Day 2 AM: Pelvis complete. Start left hip yaw (8.8hr)
Day 2 PM: Left hip yaw done. Start right hip yaw (8.8hr overnight)
```

### Day 3-5: PA6-CF — Knees + Ankles
```
Day 3: Left knee (37.3hr — runs through Day 4)
Day 4 PM: Left knee done. Start right knee (37.3hr — runs through Day 5)
Day 5 PM: Right knee done. Batch: both ankle pitch parts (2.2hr total)
```

### Day 6-8: PA12-CF — Hip & Ankle Parts
```
Day 6 AM: Switch to PA12-CF. Dry at 70°C for 2hr.
Day 6 PM: Batch: 2x hip pitch + 2x hip roll (12.2hr overnight)
Day 7 AM: Hip parts done. Start 2x ankle roll (12.4hr)
Day 7 PM: Start 2x toe links (3.0hr)
Day 8: Buffer day / reprint any failed parts
```

### Day 9-10: TPU Pads + Arm Tubes
```
Day 9: All TPU foot pads (batch 4-6 per plate, ~6hr total)
Day 10: Arm pendulum tubes (2hr). Post-processing begins.
```

### Day 11-12: Annealing + Post-Processing
```
Day 11: Anneal all 7 PA6-CF parts (130°C, 2hr hold, 4hr cool)
Day 12: Sand (220 grit), acetone wipe, Cerakote application
```

### Day 13-14: Assembly Prep
```
Day 13: Test-fit all parts. Verify bearing bores, bolt holes.
Day 14: Begin sub-assembly (pelvis + hips first)
```

**With 2 printers: Cut to 7 days** — run both knees simultaneously, batch all PA12-CF parts.

---

## PART 3: FASTENER LIST (complete BOM)

### Bolts & Screws
| Qty | Size | Type | Where |
|-----|------|------|-------|
| 12 | M5×20 | Socket head cap | Hip pivots, pelvis mount |
| 4 | M5×25 | Shoulder bolt | Knee pivots (both legs) |
| 24 | M3×10 | Socket head cap | Covers, brackets, sensor mounts |
| 8 | M3×8 | Socket head cap | Encoder mounts |
| 8 | M3×6 | Socket head cap | TPU pad mounting |
| 4 | M2×5 | Pan head | FSR sensor mounting |

### Bearings & Bushings
| Qty | Size | Type | Where |
|-----|------|------|-------|
| 12 | ID 5mm | iglidur I180 bushing | All joint pivots |
| 4 | ID 5mm | Flanged bushing | Knee pivots (thrust load) |

### Fastener Torque Specs
| Bolt | Torque | Notes |
|------|--------|-------|
| M5 into PA6-CF | 3.0 Nm | Use thread-forming screws or helicoil inserts |
| M3 into PA12-CF | 0.5 Nm | Self-tapping OK in CF-reinforced nylon |
| M3 into PA6-CF | 0.8 Nm | Pre-drill 2.5mm for M3 threads |

---

## PART 4: ASSEMBLY ORDER

### Phase 1: Pelvis Sub-Assembly
1. Install iglidur bushings into pelvis hip bores (press-fit, heat to 60°C to ease insertion)
2. Mount IMU (BNO085) to pelvis interior using M2×5
3. Route CAN bus wiring through pelvis cable channels
4. Attach WOLF actuator mounting plates for hip pitch (M5×20)

### Phase 2: Left Leg
1. Assemble left hip pitch → hip roll → hip yaw chain
2. Insert shoulder bolts through bushings at each joint
3. Mount WOLF actuator + motor at each joint
4. Wire AS5047P encoder at each joint (SPI cable)
5. Attach knee link with M5×25 shoulder bolts
6. Attach ankle pitch → ankle roll → toe assembly
7. Mount TPU foot pads with M3×6
8. Install FSR sensors in heel and toe positions

### Phase 3: Right Leg (mirror of Phase 2)

### Phase 4: Arms & Head
1. Slide arm pendulum tubes through pelvis shoulder mounts
2. Secure with M3 set screws (allow free swing)
3. Mount OAK-D camera on pan-tilt bracket (2x SG90 servos)

### Phase 5: Electronics
1. Mount RPi5 + Hailo-10H inside pelvis (top compartment)
2. Mount B-G431B-ESC1 motor controllers along leg interiors
3. Wire CAN bus daisy chain (120Ω termination at each end)
4. Connect battery (2x 6S LiPo in series = 44.4V nominal)
5. Wire power distribution with anti-spark XT90-S connector

### Phase 6: Calibration
1. Power on, run self-calibration routine (sweep all joints to mechanical stops)
2. Zero IMU (5 seconds stillness)
3. Load walking policy onto RPi5
4. Test standing balance before walking

---

## PART 5: PHYSICS VERIFICATION

### Mass Distribution (from MuJoCo simulation)
```
Pelvis:          3.50 kg (28.2%)  — ballast for low CoM
Left leg:        4.18 kg (33.7%)
Right leg:       4.18 kg (33.7%)
Arms (passive):  0.60 kg ( 4.8%)
Total:          12.44 kg
```

### Joint Torque Requirements (from trained walking policy v7-long, reward 472.9)
| Joint | Peak Torque | WOLF Limit | Margin |
|-------|-------------|------------|--------|
| Hip pitch | 76.9 Nm | 150 Nm | 49% |
| Hip roll | 49.6 Nm | 220 Nm | 77% |
| Hip yaw | 28.5 Nm | 147 Nm | 81% |
| Knee | 36.8 Nm | 176 Nm | 79% |
| Ankle pitch | 27.0 Nm | 66 Nm | 59% |
| Ankle roll | 9.9 Nm | 66 Nm | 85% |

**All joints have >49% torque margin — safe for hardware.**

### Dimensional Verification
| Part | Longest Dim | Build Vol Limit | Clearance |
|------|-------------|-----------------|-----------|
| Pelvis | 208.4mm (Z) | 380mm | 171.6mm OK |
| Knee | 369.5mm (Z) | 380mm | 10.5mm OK |
| Hip yaw | 228.8mm (Z) | 380mm | 151.2mm OK |
| All others | <200mm | 350mm | >150mm OK |

**ALL PARTS FIT. NO SPLITTING REQUIRED.**

---

## PART 6: QUALITY CHECKLIST (per part)

Before each print:
- [ ] Filament dried (PA6-CF: 90°C/4hr, PA12-CF: 70°C/2hr)
- [ ] Hardened steel nozzle installed
- [ ] Bed clean (IPA wipe)
- [ ] Chamber pre-heated to target
- [ ] Shrinkage compensation applied in slicer
- [ ] Correct infill % and wall count set
- [ ] First layer inspected for adhesion

After each print:
- [ ] Visual inspection for layer delamination
- [ ] Measure critical dimensions (bearing bores, bolt holes)
- [ ] Check for warping (place on flat surface, shine light underneath)
- [ ] Remove brim/supports cleanly
- [ ] Mark part with permanent marker (part#, date, material)

After annealing (PA6-CF only):
- [ ] Re-measure critical dimensions (expect 0.3-0.5% shrink)
- [ ] Check flatness of mating surfaces
- [ ] Test-fit bearings and bolts

---

## PART 7: MATERIAL ESTIMATE

| Material | Parts | Est. Weight | Rolls Needed | You Have |
|----------|-------|-------------|--------------|----------|
| PA6-CF | 7 structural | ~1.5 kg | 2 rolls | 3 rolls |
| PA12-CF | 8 structural | ~1.0 kg | 2 rolls | 12 rolls |
| TPU 95A | 12 pads+tubes | ~0.3 kg | 1 roll | 2 rolls |
| **Total** | **27 parts** | **~2.8 kg** | **5 rolls** | **17 rolls** |

**You have 3.4× the filament needed. Plenty for test prints and reprints.**

---

## PART 8: ADDITIONAL MATERIALS TO ORDER

| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| Cerakote H-series (Tungsten) | 1 bottle | $30 AUD | Cerakote dealer |
| XTC-3D epoxy coating | 1 kit | $25 AUD | Amazon |
| Magigoo PA (bed adhesion) | 1 bottle | $20 AUD | Amazon |
| iglidur I180 filament (optional) | 1 roll | $45 AUD | igus.com |
| M3/M5 bolt kit (stainless) | 1 set | $15 AUD | Aliexpress |
| Silica gel packs (50g) | 10 packs | $10 AUD | Amazon |
| Vacuum storage bags | 5 bags | $15 AUD | Amazon |
| Sintered steel sun gears (WOLF) | 12 pcs | $60-180 AUD | Aliexpress/gear supplier |

**Total additional materials: ~$220-360 AUD**
