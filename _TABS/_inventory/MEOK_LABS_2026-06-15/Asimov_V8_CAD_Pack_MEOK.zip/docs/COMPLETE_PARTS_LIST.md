# Asimov V8 — COMPLETE PARTS LIST (257 parts)
## All parts needed for physical build

---

## MODULE 1: WOLF ACTUATORS (×12 sets = 144 parts)

Each WOLF actuator = 12 printable parts:

| Part ID | Part | Material | Infill | Qty/set | Total |
|---------|------|----------|--------|---------|-------|
| WOLF-001 | Sun gear | PA6-CF | 100% | 1 | 12 |
| WOLF-002 | Planet gears | PA6-CF | 100% | 1 set (3-5) | 12 sets |
| WOLF-003 | Internal ring gear A | PA6-CF | 100% | 1 | 12 |
| WOLF-004 | Internal ring gear B | PA6-CF | 100% | 1 | 12 |
| WOLF-005 | Outer ring A | PA6-CF | 80% | 1 | 12 |
| WOLF-006 | Outer ring B | PA6-CF | 80% | 1 | 12 |
| WOLF-007 | Front plate | PA6-CF | 80% | 1 | 12 |
| WOLF-008 | Back plate | PA6-CF | 80% | 1 | 12 |
| WOLF-009 | Encoder housing | PA12-CF | 60% | 1 | 12 |
| WOLF-010 | Encoder magnet holder | PA12-CF | 60% | 1 | 12 |
| WOLF-011 | Alignment tool | PLA | any | 1 | 12 |
| WOLF-012 | Controller case | PA12-CF | 40% | 1 | 12 |

**Sintered steel sun gears: 12× (order, don't print)**
**Print time: ~40 hours total for all actuator parts**

---

## MODULE 2: PELVIS (5 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| PEL-001 | Hip adapter L | PA6-CF 100% | + CF cloth wrap, M5 inserts |
| PEL-002 | Hip adapter R | PA6-CF 100% | + CF cloth wrap, M5 inserts |
| PEL-003 | Cross-member | AL 2040 × 300mm | **BUY — not printed** |
| PEL-004 | Housing front | PA12-CF 60% | |
| PEL-005 | Housing rear | PA12-CF 60% | |

---

## MODULE 3-4: HIPS (13 parts × 2 = 26 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| HIP-x-001 | Motor mount | PA6-CF 100% | Steel backing plate, M5 inserts |
| HIP-x-002 | Hip pitch frame | PA6-CF 80% | CF wrap, crossed roller bearings |
| HIP-x-003 | Roll bracket upper | PA12-CF 80% | |
| HIP-x-004 | Roll bracket lower | PA12-CF 80% | |
| HIP-x-005 | Linkage A | PA6-CF 100% | Steel pin ends |
| HIP-x-006 | Linkage B | PA6-CF 100% | Steel pin ends |
| HIP-x-007 | Linkage C | PA6-CF 100% | Steel pin ends |
| HIP-x-008 | Connector upper | PA6-CF 100% | Steel dowels |
| HIP-x-009 | Connector lower | PA6-CF 100% | Steel dowels |
| HIP-x-010 | Hip housing | PA12-CF 60% | |
| HIP-x-011 | Hip cover | PA12-CF 40% | |
| HIP-x-012 | Hip bracket | PA12-CF 60% | |
| HIP-x-013 | Hip mount | PA12-CF 60% | |

---

## MODULE 5-6: KNEES (2 parts × 2 = 4 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| KNE-x-001 | Knee bracket | PA6-CF 100% | CF wrap |
| KNE-x-002 | Knee housing | PA12-CF 60% | |

---

## MODULE 7-8: FEET (6 parts × 2 = 12 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| FT-x-001 | Ankle frame | PA6-CF 80% | Steel pins at pivots |
| FT-x-002 | Bearing housing | iglidur + PA12-CF | Printed bearing surface |
| FT-x-003 | Foot frame | PA12-CF 80% | 200×80×15mm with ribs |
| FT-x-004 | Foot pad | TPU 95A 30% | Ground contact, treaded |
| FT-x-005 | Foot structure | PA12-CF 60% | |
| FT-x-006 | Toe | TPU 85A 20% | Passive spring hinge |

---

## MODULE 9: TORSO (5 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| TOR-001 | Torso spine | AL 2040 × 400mm | **BUY** |
| TOR-002 | Main panel | PA12-CF 60% | |
| TOR-003 | Side panel | PA12-CF 40% | |
| TOR-004 | Torso bracket | PA12-CF 60% | |
| TOR-005 | Compute mount | PA12-CF 40% | RPi5 + battery tray |

---

## MODULE 10-11: ARMS (9 parts × 2 = 18 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| ARM-x-001 | Shoulder frame | PA12-CF 80% | M5 inserts |
| ARM-x-002 | Upper arm | PA12-CF 60% | |
| ARM-x-003 | Elbow frame | PA12-CF 80% | M5 inserts |
| ARM-x-004 | Forearm | PA12-CF 60% | |
| ARM-x-005 | Forearm bracket | PA12-CF 40% | |
| ARM-x-006 | Wrist frame | PA12-CF 60% | |
| ARM-x-007 | Wrist bracket | PA12-CF 40% | |
| ARM-x-008 | Shoulder bearing | iglidur + PA12-CF | |
| ARM-x-009 | Wrist bearing | iglidur + PA12-CF | |

---

## MODULE 12-13: HANDS (14 parts × 2 = 28 parts)

Using Aero Hand Open instead of Amazing Hand (16 DOF vs 8 DOF).
46 STL files already cloned from TetherIA repo.

---

## MODULE 14: HEAD (3 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| HEAD-001 | Camera mount | PA12-CF 60% | OAK-D + pan-tilt servos |
| HEAD-002 | Head dome (front) | PETG black | Cerakote finish, eye cutouts |
| HEAD-003 | Head dome (rear) | PETG black | Camera slot, LED rings |

---

## MODULE 15: SAFETY (15 parts)

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| SAF-001 | E-stop mount | PA12-CF 60% | Pelvis rear panel |
| SAF-002 | Current sensor mount | PA12-CF 40% | |
| SAF-003 | TPU SEA elements ×12 | TPU 85A 100% | Thin discs, series elastic |

---

## MODULE 16: COSMETIC SHELLS (est. 12 parts) — V2

| Part ID | Part | Material | Notes |
|---------|------|----------|-------|
| SHELL-001-012 | Body panels | PETG black | Magnetic mount, Cerakote finish |

---

## NON-PRINTED PARTS TO BUY

| Item | Qty | Notes |
|------|-----|-------|
| AL 2040 extrusion 300mm | 1 | Pelvis cross-member |
| AL 2040 extrusion 400mm | 1 | Torso spine |
| Steel dowel pins 4mm × 30mm | 24 | Linkage pivots |
| Steel backing plates 2mm | 4 | Behind hip motor mounts |
| Crossed roller bearings | 4 | Hip pitch joints |
| M3 × 5mm heat-set brass inserts | 350 | All threaded connections |
| M5 × 8mm heat-set brass inserts | 24 | Major structural joints |
| CF cloth 200g/m² twill (1m²) | 1 | Wrap high-stress PA6-CF parts |
| Epoxy resin for CF wrap (500ml) | 1 | |

---

## PRINT TIME SUMMARY

| Module | Parts | Material | Est. Hours |
|--------|-------|----------|-----------|
| WOLF actuators ×12 | 144 | PA6-CF + PA12-CF | 40 |
| Pelvis | 4 printed | PA6-CF + PA12-CF | 6 |
| Hips ×2 | 26 | PA6-CF + PA12-CF | 24 |
| Knees ×2 | 4 | PA6-CF + PA12-CF | 4 |
| Feet ×2 | 12 | PA12-CF + TPU | 6 |
| Torso | 4 printed | PA12-CF | 8 |
| Arms ×2 | 18 | PA12-CF | 10 |
| Hands ×2 | 28 | PA12-CF + PA6-CF | 8 |
| Head | 3 | PA12-CF + PETG | 4 |
| Safety | 15 | PA12-CF + TPU | 2 |
| Cosmetic | 12 | PETG | 8 |
| **TOTAL** | **~270** | | **~120 hours** |

**With 1 printer: ~15-18 days continuous**
**With 2 printers: ~8-10 days**
