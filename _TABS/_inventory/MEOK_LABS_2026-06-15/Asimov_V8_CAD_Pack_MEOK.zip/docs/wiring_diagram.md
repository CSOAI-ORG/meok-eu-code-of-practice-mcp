# Asimov V8 — Wiring Diagram

## POWER DISTRIBUTION

```
Battery Pack (44.4V nominal)
├── 2x 6S LiPo in Series
├── XT90-S Anti-Spark Connector
├── 60A Main Fuse
│
├──→ 48V Bus (motors) ──────────────────────────────────────┐
│    ├── B-G431B-ESC1 #1  (L hip pitch)  ← CAN Bus A       │
│    ├── B-G431B-ESC1 #2  (L hip roll)   ← CAN Bus A       │
│    ├── B-G431B-ESC1 #3  (L hip yaw)    ← CAN Bus A       │
│    ├── B-G431B-ESC1 #4  (L knee)       ← CAN Bus A       │
│    ├── B-G431B-ESC1 #5  (L ankle pitch)← CAN Bus A       │
│    ├── B-G431B-ESC1 #6  (L ankle roll) ← CAN Bus A       │
│    ├── B-G431B-ESC1 #7  (R hip pitch)  ← CAN Bus B       │
│    ├── B-G431B-ESC1 #8  (R hip roll)   ← CAN Bus B       │
│    ├── B-G431B-ESC1 #9  (R hip yaw)    ← CAN Bus B       │
│    ├── B-G431B-ESC1 #10 (R knee)       ← CAN Bus B       │
│    ├── B-G431B-ESC1 #11 (R ankle pitch)← CAN Bus B       │
│    └── B-G431B-ESC1 #12 (R ankle roll) ← CAN Bus B       │
│                                                            │
├──→ 5V BEC #1 (3A) ── Compute ────────────────────────────┐│
│    ├── RPi5 8GB (via USB-C PD)                            ││
│    ├── Hailo-10H AI HAT+ (via RPi5 PCIe)                 ││
│    └── OAK-D Lite (via USB3)                              ││
│                                                            ││
├──→ 5V BEC #2 (2A) ── Sensors & LEDs ────────────────────┐││
│    ├── BNO085 IMU (I2C → STM32)                         │││
│    ├── ICM-45686 IMU x2 feet (SPI → STM32)              │││
│    ├── FSR sensors x8 (ADC → STM32)                     │││
│    ├── WS2812B LED strip (data → RPi5 GPIO18)           │││
│    ├── GC9A01 eye displays x2 (SPI → RPi5)             │││
│    └── SG90 servos x2 head (PWM → RPi5 GPIO)           │││
│                                                          │││
└──→ 3.3V LDO ── MCU ────────────────────────────────────┐│││
     └── STM32F446RE (real-time controller)              ││││
         ├── CAN1 → MCP2551 transceiver → CAN Bus A     ││││
         ├── CAN2 → MCP2551 transceiver → CAN Bus B     ││││
         ├── UART → RPi5 (command interface, 1Mbps)      ││││
         ├── SPI  → AS5047P encoders x12 (daisy chain)   ││││
         ├── I2C  → BNO085 IMU                           ││││
         ├── ADC  → FSR sensors x8                       ││││
         └── GPIO → Emergency stop button                ││││
```

## CAN BUS TOPOLOGY

```
CAN BUS A (Left Leg) — 1 Mbps, 22AWG shielded twisted pair
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ STM32    │    │ ESC #1   │    │ ESC #2   │    │ ESC #3   │    │ ESC #4   │    │ ESC #5   │    ┌──────────┐
│ CAN1     │────│ L_hip_p  │────│ L_hip_r  │────│ L_hip_y  │────│ L_knee   │────│ L_ank_p  │────│ ESC #6   │
│ [120Ω]   │    │          │    │          │    │          │    │          │    │          │    │ L_ank_r  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘    │ [120Ω]   │
                                                                                                └──────────┘
CAN BUS B (Right Leg) — same topology, ESC #7-12

CRITICAL: 120Ω termination resistor at EACH END only (STM32 + last ESC)
         Stub length < 30cm. Total bus length < 2m.
         Check: measure ~60Ω between CAN_H and CAN_L with multimeter.
```

## THREE-TIER COMPUTE ARCHITECTURE

```
┌─────────────────────────────────────────────────────┐
│                    TIER 1: CLOUD                     │
│              SOV3 (localhost:3101)                    │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ Language  │ │ Planning │ │ Care     │            │
│  │ (Jarvis) │ │ (Agents) │ │ Membrane │            │
│  └──────────┘ └──────────┘ └──────────┘            │
│              WiFi / MCP Bridge                       │
└───────────────────┬─────────────────────────────────┘
                    │ HTTP/WebSocket
┌───────────────────┴─────────────────────────────────┐
│              TIER 2: EDGE (RPi5 + Hailo)             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ SLAM     │ │ Object   │ │ Policy   │            │
│  │ (30Hz)   │ │ Detect   │ │ Inference│            │
│  └──────────┘ └──────────┘ └──────────┘            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ OAK-D    │ │ GR00T    │ │ LED/Eyes │            │
│  │ Camera   │ │ VLA      │ │ Control  │            │
│  └──────────┘ └──────────┘ └──────────┘            │
│              UART 1Mbps                              │
└───────────────────┬─────────────────────────────────┘
                    │
┌───────────────────┴─────────────────────────────────┐
│              TIER 3: REAL-TIME (STM32)               │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ PD Loop  │ │ Reflex   │ │ Safety   │            │
│  │ (200Hz)  │ │ Layer    │ │ Monitor  │            │
│  └──────────┘ └──────────┘ └──────────┘            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐            │
│  │ CAN A    │ │ CAN B    │ │ IMU/FSR  │            │
│  │ (L leg)  │ │ (R leg)  │ │ Sensors  │            │
│  └──────────┘ └──────────┘ └──────────┘            │
└─────────────────────────────────────────────────────┘
```

## WIRE GAUGE & CONNECTOR SPEC

| Wire | Gauge | Connector | Run |
|------|-------|-----------|-----|
| Battery main | 10 AWG silicone | XT90-S | Battery → fuse → distribution |
| Motor power | 16 AWG silicone | XT30 per ESC | Distribution → each ESC |
| CAN bus | 22 AWG shielded twisted pair | JST-PH 4-pin | Daisy chain ESC to ESC |
| Motor phase | 18 AWG silicone | 3.5mm bullet | ESC → motor (3 wires) |
| Encoder SPI | 26 AWG ribbon | JST-SH 6-pin | Encoder → STM32 |
| IMU I2C | 26 AWG | JST-SH 4-pin | IMU → STM32 |
| FSR signal | 28 AWG | JST-PH 2-pin | FSR → STM32 ADC |
| RPi-STM32 | 26 AWG | JST-SH 4-pin | UART TX/RX/GND/3.3V |
| LED data | 24 AWG | JST-SM 3-pin | RPi5 GPIO → LED strip |
| 5V power | 18 AWG | Barrel jack | BEC → compute |

## E-STOP

```
E-STOP BUTTON (mushroom head, panel mount on pelvis rear)
  │
  ├── Cuts 48V motor bus (normally closed relay)
  ├── Sends GPIO interrupt to STM32 (immediate motor disable)
  └── STM32 sends CAN broadcast: all ESCs → zero torque
  
Recovery: twist E-stop to release, power cycle required
```
