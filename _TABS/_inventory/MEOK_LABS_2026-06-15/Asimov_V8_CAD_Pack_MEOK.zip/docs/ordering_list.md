# Asimov V8 — Complete Ordering List
## Order NOW — items have 1-4 week lead times

---

## PRIORITY 1: Order Immediately (needed before/during print)

### Fasteners (Aliexpress — 1-2 week delivery)
| Item | Qty | Est. Cost | Link Search |
|------|-----|-----------|-------------|
| M5x20 socket head cap bolt (stainless) | 20 | $5 | "M5x20 socket head cap screw stainless" |
| M5x25 shoulder bolt (5mm shoulder) | 8 | $8 | "M5x25 shoulder bolt stainless" |
| M3x10 socket head cap bolt (stainless) | 50 | $4 | "M3x10 socket head cap screw stainless 100pcs" |
| M3x8 socket head cap bolt | 20 | $3 | "M3x8 socket head stainless" |
| M3x6 socket head cap bolt | 20 | $3 | "M3x6 socket head stainless" |
| M2x5 pan head screw | 10 | $2 | "M2x5 pan head screw stainless" |
| M3 nylon lock nuts | 50 | $3 | "M3 nylon lock nut stainless" |
| M5 nylon lock nuts | 20 | $3 | "M5 nylon lock nut stainless" |
| **Subtotal** | | **~$31** | |

### Bearings & Bushings
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| iglidur GFM-0506-06 bushing (ID5mm) | 16 | $32 | igus.com.au |
| OR: iglidur I180 filament (250g) | 1 | $45 | igus.com.au (print your own) |
| **Subtotal** | | **~$35-45** | |

### WOLF Actuator Specific
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| Sintered steel sun gear (module 1.0, 20T) | 12 | $60-180 | Aliexpress "sintered gear module 1" or SDP-SI |
| M3x5mm brass heat-set inserts | 350 | $15 | Aliexpress "M3 heat set insert brass" |
| Super-Lube 21030 grease | 1 tube | $12 | Amazon |
| **Subtotal** | | **~$90-210** | |

### Print Consumables
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| Magigoo PA (bed adhesion for nylon) | 1 | $20 | Amazon AU |
| Silica gel 50g packs | 10 | $10 | Amazon AU |
| Vacuum storage bags (large) | 5 | $15 | Amazon AU |
| Hardened steel nozzle 0.4mm (if not installed) | 2 | $15 | Amazon AU / Qidi store |
| **Subtotal** | | **~$60** | |

---

## PRIORITY 2: Order This Week (needed for assembly)

### Motors & Controllers
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| 8318 100KV BLDC motor | 12 | $480 | Aliexpress "8318 100KV brushless motor" |
| 5010 310KV BLDC motor (ankles) | 4 | $80 | Aliexpress "5010 310KV" |
| B-G431B-ESC1 motor controller | 12 | $216 | LCSC / Mouser / Aliexpress |
| AS5047P magnetic encoder breakout | 12 | $60 | Aliexpress / Mouser |
| 6x2.5mm diametric magnet (for encoders) | 12 | $8 | Aliexpress |
| MCP2551 CAN transceiver module | 12 | $24 | Aliexpress |
| **Subtotal** | | **~$868** | |

### Compute
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| Raspberry Pi 5 8GB | 1 | $120 | Core Electronics AU |
| Hailo-10H AI HAT+ 2 (40 TOPS) | 1 | $200 | RPi official / Seeed |
| STM32F446RE Nucleo board | 1 | $25 | Mouser / Element14 |
| **Subtotal** | | **~$345** | |

### Sensors
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| BNO085 IMU breakout (Adafruit) | 1 | $25 | Core Electronics AU |
| ICM-45686 breakout (foot IMUs) | 2 | $20 | Aliexpress |
| FSR 402 force sensitive resistor | 8 | $24 | Aliexpress / Core Electronics |
| OAK-D Lite camera | 1 | $149 | Luxonis.com |
| **Subtotal** | | **~$218** | |

### Battery & Power
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| 6S 5000mAh 30C LiPo | 2 | $100 | HobbyKing AU |
| XT90-S anti-spark connector pair | 2 | $8 | HobbyKing |
| 5V 5A BEC (UBEC) | 2 | $16 | Aliexpress |
| 60A circuit breaker (resettable) | 1 | $10 | Aliexpress |
| E-stop mushroom button (panel mount) | 1 | $8 | Aliexpress |
| 10F 50V supercapacitor (hot-swap) | 1 | $15 | Aliexpress |
| **Subtotal** | | **~$157** | |

### Wiring
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| 22AWG shielded twisted pair (10m) | 1 | $12 | Aliexpress |
| 16AWG silicone wire (red+black, 5m each) | 1 | $10 | Aliexpress |
| 10AWG silicone wire (red+black, 1m each) | 1 | $6 | Aliexpress |
| JST-PH 4-pin connectors (20 sets) | 1 | $6 | Aliexpress |
| JST-SH 6-pin connectors (15 sets) | 1 | $6 | Aliexpress |
| XT30 connectors (12 pairs) | 1 | $8 | Aliexpress |
| 120Ω resistors (CAN termination) | 4 | $1 | Aliexpress |
| Heat shrink assortment | 1 | $5 | Amazon |
| **Subtotal** | | **~$54** | |

---

## PRIORITY 3: Order During Print Phase (aesthetic)

### Finishing Materials
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| Cerakote H-series (Midnight or Tungsten) | 1 | $35 | Cerakote dealer AU |
| XTC-3D epoxy coating (Smooth-On) | 1 kit | $26 | Amazon AU |
| Rust-Oleum Filler Primer (gray) | 2 cans | $16 | Bunnings |
| Sandpaper wet/dry set (120-800) | 1 | $12 | Bunnings |
| **Subtotal** | | **~$89** | |

### Cosmetic Shell Materials
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| eSun PETG Black (1kg) | 2 | $44 | Amazon AU |
| Clear/Natural TPU 95A (500g) | 1 | $18 | Amazon AU |
| UV cure resin (clear, 200ml) | 1 | $12 | Amazon AU |
| Neodymium magnets 6x3mm N52 (100pcs) | 1 | $15 | Aliexpress |
| **Subtotal** | | **~$89** | |

### Head & Display
| Item | Qty | Est. Cost | Source |
|------|-----|-----------|--------|
| GC9A01 1.28" round IPS display | 2 | $16 | Aliexpress |
| WS2812B LED ring 16-LED (for eyes) | 2 | $6 | Aliexpress |
| WS2812B LED strip 60/m IP30 (2m) | 1 | $6 | Aliexpress |
| SG90 micro servo (head pan/tilt) | 2 | $4 | Aliexpress |
| USB microphone (small) | 1 | $8 | Amazon AU |
| Small speaker (3W, 40mm) | 1 | $5 | Aliexpress |
| **Subtotal** | | **~$45** | |

---

## GRAND TOTAL

| Category | Cost (AUD) |
|----------|-----------|
| Fasteners & hardware | $126-246 |
| Motors & controllers | $868 |
| Compute | $345 |
| Sensors | $218 |
| Battery & power | $157 |
| Wiring | $54 |
| Finishing materials | $89 |
| Cosmetic shells | $89 |
| Head & display | $45 |
| Filament (already owned) | $0 |
| **TOTAL** | **$1,991-2,111 AUD** |

**Plus filament you already have (17 rolls) = ~$800 value**
**Grand total invested: ~$2,800-2,900 AUD** — under $3K target.

---

## ORDER ACTIONS

### Today:
- [ ] Aliexpress: fastener kit, heat-set inserts, magnets, CAN transceivers, FSR sensors
- [ ] Amazon AU: Magigoo PA, silica gel, vacuum bags, sandpaper, XTC-3D
- [ ] Core Electronics: RPi5, BNO085

### This Week:
- [ ] Aliexpress: 8318 motors, B-G431B-ESC1, AS5047P encoders, 5010 motors
- [ ] HobbyKing: 2x 6S LiPo, XT90-S connectors
- [ ] Luxonis: OAK-D Lite
- [ ] Seeed/RPi: Hailo-10H AI HAT+ 2

### During Print Phase:
- [ ] Cerakote dealer: H-series coating
- [ ] Bunnings: Filler primer
- [ ] Aliexpress: LED strips, displays, servos, speaker
- [ ] Amazon: PETG black, clear TPU, UV resin
