# Customer #1 — Day 11 Activation
See MEMORY.md for the live onboarding record.
